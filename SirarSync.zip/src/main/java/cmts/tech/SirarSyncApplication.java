package cmts.tech;

public class SirarSyncApplication {
    public static void main(String[] args) {
        System.out.println("SirarSync Application Running...");
    }
}
